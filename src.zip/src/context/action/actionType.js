export const ADD_TO_HEART = 'ADD_TO_HEART';
export const DEL_FROM_HEART = 'DEL_FROM_HEART'

export const DROPDOWN = 'DROPDOWN'

export const ADD_TO_CART = 'ADD_TO_CART';
export const DEL_FROM_CART = 'DEL_FROM_CART'
export const DEC_FROM_CART = 'DEC_FROM_CART'